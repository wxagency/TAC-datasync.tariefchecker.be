<?php

namespace App\Console\Commands\Restore;

use Illuminate\Console\Command;
use App\Models\History\Supplier;
use Carbon\Carbon;
use Illuminate\Support\Facades\Session;
use App\Console\Commands\Restore\AirtableTrait;


class SupplierUpdate extends Command
{
    use AirtableTrait;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'supplier:update';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->info("---Supplier Restore started--");
        $this->_update();
        $this->info("---Supplier Restore ended--");
        
        // $this->_test();
    }


    private function _update()
    {
        $restoreDate = $this->getRestoreDate(); 
        if( $restoreDate == false){
            $this->info("---No restore point found--");
            exit;
        }
        $current_supplier = [];
        $new_supplier = [];
        $data = Supplier::where('backupdate', $restoreDate)->get()->toArray();
        Session::put('offset', '0');
        while (Session::get('offset') != 'stop') {

            $query['pageSize'] = 100;
            $query['offset'] = Session::get('offset');

            $json = $this->get('Suppliers', $query);

            if (isset($json['offset'])) {
                Session::put('offset', $json['offset']);
            } else {

                Session::put('offset', 'stop');
            }

            // Here key is the unique value in the Supplier table and Value is the auto generated ID

            foreach ($json['records'] as $supplier) {

                $current_supplier[$supplier['fields']['Id']] = $supplier['id'];
            }
        }


        $new_supplier = $data;
        $create_record = [];
        $update_record = [];

        foreach ($new_supplier as $key => $value) {
            $_id = isset($current_supplier[$value['supplier_id']]) ? $current_supplier[$value['supplier_id']] : '';
            if (strlen($_id) > 0) {
                $record = $this->_formatRecord($value, $_id);
                array_push($update_record, $record);
                unset($current_supplier[$value['supplier_id']]);
                if (count($update_record) == 10) {
                    $this->_updateRecords($update_record);
                    $update_record = [];
                }
            } else {
                $record = $this->_formatRecord($value, $_id);
                array_push($create_record, $record);
                if (count($create_record) == 10) {
                    $this->_createRecords($create_record);
                    $create_record = [];
                }
            }
        }

        if (count($update_record) > 0) {
            $this->_updateRecords($update_record);
            $update_record = [];
        }

        if (count($create_record) > 0) {
            $this->_createRecords($create_record);
            $create_record = [];
        }

        $delete_records = [];
        foreach ($current_supplier as $id => $autoKey) {
            $delete_records[] = urlencode($autoKey);
            if (count($delete_records) == 10) {
                $this->_deleteRecord($delete_records);
                $delete_records = [];
            }
        }

        if (count($delete_records) > 0) {
            $this->_deleteRecord($delete_records);
            $delete_records = [];
        }
        // $this->info("completed");

    }

    /**
     * Setting the exact format of each record to restore.
     */
    function _formatRecord($record, $_id = '')
    {

        $newData = [
            'Id' => $record['supplier_id'],
            'Supplier Type'  =>  $this->get_value($record['suppliertype']),
            'Origin'  =>  $this->get_value($record['origin']),
            'Official Name'  =>  $record['official_name'],
            'Commercial Name'  =>  $record['commercial_name'],
            'Abbreviation'  =>  $record['abbreviation'],
            'Parent Company'  =>  $record['parent_company'],
            'Logo Large'  =>  $record['logo_large'],
            'Logo Small'  =>  $record['logo_small'],
            'Website'  =>  $record['website'],
            'Youtube Video'  =>  $record['youtube_video'],
            'Video Webm'  =>  $record['video_webm'],
            'B2b Customers'  =>  $record['B2b_customers'],
            'B2c Customers'  =>  $record['B2c_customers'],
            'Greenpeace Rating'  =>  $this->get_value($record['greenpeace_rating']),
            'Vreg Rating'  =>  $this->get_value($record['Vreg_rating']),
            'Customer Rating'  =>  $this->get_value($record['customer_rating']),
            'Advice Rating'  =>  $this->get_value($record['advice_rating']),
            'Presentation'  =>  $record['presentation'],
            'Mission Vision'  =>  $record['mission_vision'],
            'Values'  =>  $record['supplier_values'],
            'Services'  =>  $record['services'],
            'Mission Vision Image'  =>  $record['mission_vision_image'],
            'Facebook Page'  =>  $record['facebook_page'],
            'Twitter Name'  =>  $record['twitter_name'],
            'Location'  =>  $record['location'],
            'Video Mp4'  =>  $record['video_mp4'],
            'Video Ogg'  =>  $record['video_ogg'],
            'Video Flv'  =>  $record['video_flv'],
            'Greenpeace Report'  =>  $record['greenpeace_report'],
            'Greenpeace Report Url'  =>  $record['greenpeace_report_url'],
            'Greenpeace Supplier Response'  =>  $record['greenpeace_supplier_response'],
            'Greenpeace Production Image'  =>  $record['greenpeace_production_image'],
            'Greenpeace Investments Image'  =>  $record['greenpeace_investments_image'],
            'Greenpeace Report Pdf'  =>  $record['greenpeace_report_pdf'],
            'Tagline'  =>  $record['tagline'],
            'Vimeo Url'  =>  $record['vimeo_url'],
            'Is Partner'  => $this->get_value($record['is_partner']),
            'Customer Reviews'  =>  $record['customer_reviews'],
            'Logo Medium'  =>  $record['logo_medium'],
            'Conversion Value'  =>  $record['conversion_value'],
        ];
        $result = [
            'fields' =>  $newData,
        ];
        if (strlen($_id) > 0) {
            $result['id'] = $_id;
        }


        return $result;
    }

    /**
     * update the records
     */
    private function _updateRecords($records)
    {

        $requestData = [
            'records' => $records
        ];

        $this->patch('Suppliers', $requestData, [
            'error' => function ($ex, $data) {
                // die($ex->getMessage());
            }
        ]);
    }

    private function _createRecords($records)
    {
        $requestData = [
            'records' => $records
        ];

        $this->post('Suppliers', $requestData, [
            'error' => function ($ex, $data) {
                // die($ex->getMessage());
            }
        ]);
    }


    function _deleteRecord($data)
    {
        $requestData = [
            'records' => $data
        ];

        if (count($requestData['records'])) {

            $this->delete('Suppliers', $requestData, [
                'error' => function ($ex, $data) {
                    // die($ex->getMessage());
                }
            ]);
        }
    }
}
